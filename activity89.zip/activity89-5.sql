-- Activity 9 - Retrieving Invoice Slip Data QUERY 5

SELECT
  Products.ProductNumber,
  Products.ProductName,
  InvoiceDetails.LineTotal,
  InvoiceDetails.OrderQty,
  InvoiceDetails.UnitPrice
FROM InvoiceDetails
INNER JOIN Products
  ON InvoiceDetails.ProductNumber = Products.ProductNumber
WHERE InvoiceDetails.InvoiceID = 3;
