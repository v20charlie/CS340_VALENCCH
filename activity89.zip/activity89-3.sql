-- Actiivity 8: SQL Queries of Multiple Tables (JOINS) QUERYL 3

SELECT
  Customers.CustomerName,
  Invoices.InvoiceID,
  SUM(InvoiceDetails.LineTotal) AS LineSum
FROM Customers
INNER JOIN Invoices
  ON Customers.CustomerID = Invoices.CustomerID
INNER JOIN InvoiceDetails
  ON Invoices.InvoiceID = InvoiceDetails.InvoiceID
GROUP BY Invoices.InvoiceID
ORDER BY LineSum DESC;

