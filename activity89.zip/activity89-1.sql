-- Actiivity 8: SQL Queries of Multiple Tables (JOINS) QUERYL 1

SELECT ProductNumber, ProductName, ListPrice
FROM Products
ORDER BY ListPrice DESC;
