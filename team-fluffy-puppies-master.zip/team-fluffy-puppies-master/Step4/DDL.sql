-- CS340 W26 - Group 2 - Team Fluffy Puppies
-- Team Members: Devin Gaughan, Charlene Valencia
-- Project Step 4 DRAFT - DDL + Sample Data wrapped in RESET procedure

DELIMITER //

CREATE PROCEDURE ResetDatabase()
BEGIN
    -- We need to disable foreign key checks first so we don't get constraint errors when dropping
    SET FOREIGN_KEY_CHECKS=0;
    
    -- Drop tables in reverse order of dependencies to be safe
    DROP TABLE IF EXISTS Prescriptions;
    DROP TABLE IF EXISTS Appointments;
    DROP TABLE IF EXISTS Pets;
    DROP TABLE IF EXISTS Medications;
    DROP TABLE IF EXISTS Vets;
    DROP TABLE IF EXISTS Owners;

    -- Table: Owners
    CREATE TABLE Owners (
        ownerID INT AUTO_INCREMENT NOT NULL,
        firstName VARCHAR(50) NOT NULL,
        lastName VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        phoneNumber VARCHAR(15) NOT NULL,
        PRIMARY KEY (ownerID)
    );

    -- Table: Vets
    CREATE TABLE Vets (
        vetID INT AUTO_INCREMENT NOT NULL,
        firstName VARCHAR(50) NOT NULL,
        lastName VARCHAR(50) NOT NULL,
        licenseNumber VARCHAR(20) NOT NULL UNIQUE,
        specialization VARCHAR(50),
        PRIMARY KEY (vetID)
    );

    -- Table: Medications
    CREATE TABLE Medications (
        medicationID INT AUTO_INCREMENT NOT NULL,
        name VARCHAR(100) NOT NULL,
        brand VARCHAR(100),
        unitCost DECIMAL(19,2) NOT NULL,
        stockQuantity INT NOT NULL,
        PRIMARY KEY (medicationID)
    );

    -- Table: Pets
    CREATE TABLE Pets (
        petID INT AUTO_INCREMENT NOT NULL,
        name VARCHAR(50) NOT NULL,
        species VARCHAR(50) NOT NULL,
        breed VARCHAR(50),
        dateOfBirth DATE,
        nextVaccinationDate DATE,
        ownerID INT NOT NULL,
        PRIMARY KEY (petID),
        FOREIGN KEY (ownerID) 
            REFERENCES Owners(ownerID) 
            ON DELETE CASCADE
            ON UPDATE CASCADE
    );

    -- Table: Appointments
    CREATE TABLE Appointments (
        appointmentID INT AUTO_INCREMENT NOT NULL,
        date DATETIME NOT NULL,
        description TEXT NOT NULL,
        totalCost DECIMAL(19,2) NOT NULL,
        paymentStatus VARCHAR(20) NOT NULL,
        petID INT NOT NULL,
        vetID INT NOT NULL,
        PRIMARY KEY (appointmentID),
        FOREIGN KEY (petID)
            REFERENCES Pets(petID) 
            ON DELETE CASCADE
            ON UPDATE CASCADE,
        FOREIGN KEY (vetID)
            REFERENCES Vets(vetID) 
            ON DELETE RESTRICT
            ON UPDATE CASCADE
    );

    -- Table: Prescriptions
    CREATE TABLE Prescriptions (
        prescriptionID INT AUTO_INCREMENT NOT NULL,
        appointmentID INT NOT NULL,
        medicationID INT NOT NULL,
        dosage VARCHAR(255) NOT NULL,
        quantityPrescribed INT NOT NULL,
        PRIMARY KEY (prescriptionID),
        FOREIGN KEY (appointmentID) 
            REFERENCES Appointments(appointmentID) 
            ON DELETE CASCADE
            ON UPDATE CASCADE,
        FOREIGN KEY (medicationID) 
            REFERENCES Medications(medicationID) 
            ON DELETE RESTRICT 
            ON UPDATE CASCADE
    );

    -- Inserting our initial sample data
    INSERT INTO Owners (firstName, lastName, email, phoneNumber)
    VALUES 
    ('Devin', 'Gaughan', 'devin@email.com', '555-0101'),
    ('Charlene', 'Valencia', 'charlene@email.com', '555-0102'),
    ('Ash', 'Ketchum', 'ash@email.com', '555-0103');

    INSERT INTO Vets (firstName, lastName, licenseNumber, specialization)
    VALUES 
    ('Sarah', 'Smith', 'VET12345', 'Surgery'),
    ('James', 'Herriot', 'VET67890', 'General Practice'),
    ('John', 'Dolittle', 'VET11111', 'Exotics');

    INSERT INTO Medications (name, brand, unitCost, stockQuantity)
    VALUES 
    ('Amoxicillin', 'Generic', 15.00, 100),
    ('Rimadyl', 'Zoetis', 35.50, 50),
    ('Frontline Plus', 'Merial', 45.00, 200),
    ('Gabapentin', 'Generic', 12.00, 150);

    INSERT INTO Pets (name, species, breed, dateOfBirth, nextVaccinationDate, ownerID)
    VALUES 
    ('Luna', 'Cat', 'Domestic Short Hair', '2025-10-01', '2026-03-01', 1),
    ('Sol', 'Cat', 'Domestic Short Hair', '2025-10-01', '2026-03-01', 1),
    ('Buddy', 'Dog', 'Golden Retriever', '2020-05-15', '2026-04-10', 2),
    ('Tweety', 'Bird', 'Canary', NULL, NULL, 3);

    INSERT INTO Appointments (date, description, totalCost, paymentStatus, petID, vetID)
    VALUES 
    ('2026-02-01 10:30:00', 'Kitten Vaccination', 85.00, 'Paid', 1, 2),
    ('2026-02-01 11:00:00', 'Kitten Vaccination', 85.00, 'Paid', 2, 2),
    ('2026-02-02 14:00:00', 'Limping/Checkup', 150.00, 'Pending', 3, 1),
    ('2026-02-03 09:15:00', 'Annual Checkup', 60.00, 'Paid', 4, 3);

    INSERT INTO Prescriptions (appointmentID, medicationID, dosage, quantityPrescribed)
    VALUES 
    (3, 2, 'One tablet daily with food', 14), 
    (3, 4, 'One capsule every 12 hours', 20), 
    (1, 3, 'Apply topical monthly', 1);

    -- Turn foreign key checks back on so data integrity is maintained moving forward
    SET FOREIGN_KEY_CHECKS=1;

END //

DELIMITER ;