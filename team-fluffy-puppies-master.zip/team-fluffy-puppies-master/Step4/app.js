// app.js
// CS340 W26 - Group 2 - Team Fluffy Puppies
// Team Members: Devin Gaughan, Charlene Valencia

const express = require('express');
const { engine } = require('express-handlebars');
const app = express();
const PORT = 7515;

// Setting up our database connection
// We are using this to handle all queries to the MariaDB server.
const db = require('./database/db-connector');

// Middleware to parse URL-encoded bodies so we can read form data for our DELETE operation
app.use(express.urlencoded({ extended: true }));

app.engine('handlebars', engine({ defaultLayout: 'main' }));
app.set('view engine', 'handlebars');
app.use(express.static('public'));

// ----------------------------------------------------------------------------
// ROUTES FOR BROWSABLE UI (SELECT Operations)
// We replaced the hardcoded Step 3 arrays with actual SELECT queries to our database.
// ----------------------------------------------------------------------------

app.get('/', (req, res) => res.render('index'));

app.get('/owners', (req, res) => {
    // Pulling all owners from the database to populate the table.
    let query = "SELECT * FROM Owners;";
    db.pool.query(query, function(error, rows, fields) {
        if (error) {
            console.log("Error fetching Owners: ", error);
            res.sendStatus(500);
        } else {
            res.render('owners', { data: rows });
        }
    });
});

app.get('/pets', (req, res) => {
    // Grabbing all pets. This is also the page where we decided to implement 
    // our demo DELETE operation for the assignment.
    let query = "SELECT * FROM Pets;";
    db.pool.query(query, function(error, rows, fields) {
        if (error) {
            console.log("Error fetching Pets: ", error);
            res.sendStatus(500);
        } else {
            res.render('pets', { data: rows });
        }
    });
});

app.get('/vets', (req, res) => {
    let query = "SELECT * FROM Vets;";
    db.pool.query(query, function(error, rows, fields) {
        if (error) {
            console.log("Error fetching Vets: ", error);
            res.sendStatus(500);
        } else {
            res.render('vets', { data: rows });
        }
    });
});

app.get('/medications', (req, res) => {
    let query = "SELECT * FROM Medications;";
    db.pool.query(query, function(error, rows, fields) {
        if (error) {
            console.log("Error fetching Medications: ", error);
            res.sendStatus(500);
        } else {
            res.render('medications', { data: rows });
        }
    });
});

app.get('/appointments', (req, res) => {
    let query = "SELECT * FROM Appointments;";
    db.pool.query(query, function(error, rows, fields) {
        if (error) {
            console.log("Error fetching Appointments: ", error);
            res.sendStatus(500);
        } else {
            res.render('appointments', { data: rows });
        }
    });
});

app.get('/prescriptions', (req, res) => {
    let query = "SELECT * FROM Prescriptions;";
    db.pool.query(query, function(error, rows, fields) {
        if (error) {
            console.log("Error fetching Prescriptions: ", error);
            res.sendStatus(500);
        } else {
            res.render('prescriptions', { data: rows });
        }
    });
});

// ----------------------------------------------------------------------------
// RESET & CUD OPERATIONS
// ----------------------------------------------------------------------------

// Route to trigger our ResetDatabase stored procedure. 
// We linked this to a button in the main navigation bar.
app.get('/reset-db', (req, res) => {
    let query = "CALL ResetDatabase();";
    db.pool.query(query, function(error, rows, fields) {
        if (error) {
            console.log("Error resetting database: ", error);
            res.sendStatus(500);
        } else {
            // Once the DB is successfully reset, bring the user back to the home page.
            res.redirect('/');
        }
    });
});

// This is the single CUD operation required to demo the reset functionality.
// It takes a petID from a form submission and executes our DeletePet procedure.
app.post('/delete-pet', (req, res) => {
    let petID = parseInt(req.body.petID);
    let query = "CALL DeletePet(?);";
    
    db.pool.query(query, [petID], function(error, rows, fields) {
        if (error) {
            console.log("Error deleting pet: ", error);
            res.sendStatus(500);
        } else {
            // Send them back to the pets page to see the table updated
            res.redirect('/pets');
        }
    });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));