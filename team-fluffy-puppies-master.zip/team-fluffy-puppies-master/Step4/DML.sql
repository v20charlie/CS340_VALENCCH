-- FLUFFY FRIENDS CLINIC - Group 2 (Devin Gaughan & Charlene Valencia)
-- The ':' character denotes variables that will be passed from the backend

-- ---------------------------------------------------
-- OWNERS
-- ---------------------------------------------------

-- Browse all Owners
SELECT ownerID, firstName, lastName, email, phoneNumber FROM Owners;

-- Register a new Owner
INSERT INTO Owners (firstName, lastName, email, phoneNumber)
VALUES (:firstNameInput, :lastNameInput, :emailInput, :phoneNumberInput);

-- ---------------------------------------------------
-- PETS
-- ---------------------------------------------------

-- Browse all Pets (JOINed with Owners to show owner name instead of ID)
SELECT Pets.petID, Pets.name, Pets.species, Pets.breed, Pets.dateOfBirth, 
       Pets.nextVaccinationDate, CONCAT(Owners.firstName, ' ', Owners.lastName) AS ownerName
FROM Pets
INNER JOIN Owners ON Pets.ownerID = Owners.ownerID;

-- Register a new Pet with vaccination reminder date
INSERT INTO Pets (name, species, breed, dateOfBirth, nextVaccinationDate, ownerID)
VALUES (:nameInput, :speciesInput, :breedInput, :dateOfBirthInput, :nextVaccinationDateInput, :ownerID_from_dropdown);

-- UPDATE: Modify pet details
UPDATE Pets 
SET nextVaccinationDate = :nextVacDateInput, breed = :breedInput 
WHERE petID = :petID_from_form; [cite: 730]

-- DELETE: Remove a pet profile
DELETE FROM Pets WHERE petID = :petID_selected;

-- ---------------------------------------------------
-- VETS
-- ---------------------------------------------------

-- Browse all Vets
SELECT vetID, firstName, lastName, licenseNumber, specialization FROM Vets;

-- Add a new Vet
INSERT INTO Vets (firstName, lastName, licenseNumber, specialization)
VALUES (:firstNameInput, :lastNameInput, :licenseNumberInput, :specializationInput);

-- ---------------------------------------------------
-- MEDICATIONS
-- ---------------------------------------------------

-- Browse all Medications
SELECT medicationID, name, brand, unitCost, stockQuantity FROM Medications;

-- Add a new Medication
INSERT INTO Medications (name, brand, unitCost, stockQuantity)
VALUES (:nameInput, :brandInput, :unitCostInput, :stockQuantityInput);

-- UPDATE: Adjust stock levels
UPDATE Medications SET stockQuantity = :newQty WHERE medicationID = :medID;

-- ---------------------------------------------------
-- APPOINTMENTS
-- ---------------------------------------------------

-- Browse all Appointments (JOINed with Pets and Vets for user-friendly display)
SELECT appt.appointmentID, appt.date, appt.description, appt.totalCost, 
       appt.paymentStatus, Pets.name AS petName, Vets.lastName AS vetName
FROM Appointments appt
INNER JOIN Pets ON appt.petID = Pets.petID
INNER JOIN Vets ON appt.vetID = Vets.vetID;

-- Log a new Appointment (Historical billing tracking)
INSERT INTO Appointments (date, description, totalCost, paymentStatus, petID, vetID)
VALUES (:dateInput, :descriptionInput, :totalCostInput, :paymentStatusInput, :petID_dropdown, :vetID_dropdown);

-- UPDATE: Manage billing status (Addressing "lost billing hours")
UPDATE Appointments SET paymentStatus = :newStatus WHERE appointmentID = :apptID;

-- ---------------------------------------------------
-- PRESCRIPTIONS (Intersection Table)
-- ---------------------------------------------------

-- Browse all Prescriptions (JOINed to show Appointment Date and Medication Name)
SELECT pres.prescriptionID, appt.date AS apptDate, meds.name AS medName, 
       pres.dosage, pres.quantityPrescribed
FROM Prescriptions pres
INNER JOIN Appointments appt ON pres.appointmentID = appt.appointmentID
INNER JOIN Medications meds ON pres.medicationID = meds.medicationID;

-- Issue new Prescription (M:M relationship insertion)
INSERT INTO Prescriptions (appointmentID, medicationID, dosage, quantityPrescribed)
VALUES (:apptID_dropdown, :medID_dropdown, :dosageInput, :quantityInput);

-- UPDATE: Edit prescription dosage or quantity
UPDATE Prescriptions 
SET dosage = :dosageInput, quantityPrescribed = :qtyInput 
WHERE prescriptionID = :presID;

-- DELETE: Remove a prescription record
DELETE FROM Prescriptions WHERE prescriptionID = :presID_selected;