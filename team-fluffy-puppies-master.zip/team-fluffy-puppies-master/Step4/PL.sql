-- CS340 W26 - Group 2 - Team Fluffy Puppies
-- Team Members: Devin Gaughan, Charlene Valencia
-- Project Step 4 DRAFT - PL/SQL Procedures

DELIMITER //

-- We created this simple procedure to handle a DELETE operation so we can easily demonstrate 
-- our RESET functionality working on the UI for Step 4. 
CREATE PROCEDURE DeletePet(IN p_petID INT)
BEGIN
    DELETE FROM Pets WHERE petID = p_petID;
END //

DELIMITER ;